/*
 * Jonathan Nushi
 */

 class Indeedee implements Pokemon{
    public String name(){
        return "Indeedee";
    }

    public String nameOfSet(){
        return "Indeedee";
    }

    public String set(){
       return "https://pokepast.es/01378c525c48aac3";
    }

    public String description(){
        return "Indeedee is a relatively lackluster Pokemon on its own. However, it has a very powerful ability in Psychic Surge, which enables some extremely powerful synergies that are right up the alley of any Hyper Offense team. Psychic Terrain has two general effects: Psychic moves are boosted in base power by 1.3x, and all priority attacks are completely negated. Other specific attack and item interactions will be discussed within the entries for other Pokemon that will begin to be recommended by the program once Indeedee is added to your team, as Psychic Terrain enables these specific strategies. Psychic Terrain is a particularly powerful Hyper Offense strategy as not only is the boost to Psychic attacks so desirable, but the negation of priority attacks makes your Pokemon much more difficult to be revenge KO’d.";
    }
 }