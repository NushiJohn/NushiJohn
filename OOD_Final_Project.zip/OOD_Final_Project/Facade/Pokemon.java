/*
 * Jonathan Nushi
 */
public interface Pokemon{
    public String name();
    public String nameOfSet();
    public String set();
    public String description();
}