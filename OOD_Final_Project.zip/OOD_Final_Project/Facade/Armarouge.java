/*
 * Jonathan Nushi
 */

 class Armarouge implements Pokemon{
    public String name(){
        return "Armarouge";
    }

    public String nameOfSet(){
        return "Armarouge";
    }

    public String set(){
       return "https://pokepast.es/cadf0e61fe8353a5";
    }

    public String description(){
        return "Armarouge is one of the perfect abusers of Psychic Terrain thanks to its typing and access to Expanding Force. Expanding Force is a Base 80 Power Psychic Type attack that enjoys the typical 1.3x boost from Psychic Terrain, but it gains an additional 1.5x boost in Base Power while Psychic Terrain is up. With these boosts, in addition to STAB, Armarouge is able to immediately let off a Base 234 Power attack the moment it enters battle, provided that Psychic Terrain is in effect. With the Focus Sash, as long as Armarouge hasn’t suffered any chip damage and is at full health, it should be guaranteed to at least click Expanding Force once. If your opponent chooses to send in a Pokemon slower than Armarouge after it has KO’d one Pokemon, it can click Destiny Bond if you suspect that they are going to immediately try to KO Armarouge. Destiny Bond will KO Armarouge’s opponent if they KO it with a direct attack immediately after the move was used. Armarouge is a key component in Psychic Terrain Hyper Offense as it can muscle through key components of your opponent’s defensive core.";
    }
 }