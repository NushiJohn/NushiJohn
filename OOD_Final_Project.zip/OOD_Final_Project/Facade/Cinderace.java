/*
 * Jonathan Nushi
 */

 class Cinderace implements Pokemon{
    public String name(){
        return "Cinderace";
    }

    public String nameOfSet(){
        return "Cincderace";
    }

    public String set(){
       return "https://pokepast.es/b10cdaf0e3c3de20";
    }

    public String description(){
        return "Similar to Greninja and Meowscarada, Cinderace is a fast and hard hitting Pokemon thanks to its high offensive stats and Libero ability, which changes Cinderace’s typing to that of whatever attack it is using right before it attacks, giving whatever attack Cinderace uses a 1.5x boost in power. Cinderace has a bevy of coverage and utility options, so it can be highly customizable for your team’s specific needs. Cinderace reverts to its original typing once it switches out, so the Heavy-Duty-Boots are highly recommended to minimize hazard damage, as Cinderace will likely be entering and exiting the field very frequently. Cinderace also makes slightly better use out of Libero than Greninja and Meowscarada thanks to the fact it is a pure Fire type, meaning that Libero will not activate if Cinderace uses Pyro Ball first; meaning that Cinerace can use Pyro Ball and then another attack and still get the Libero boost on its second attack.";
    }
 }