/*
 * Jonathan Nushi
 */

 class Polteageist implements Pokemon{
    public String name(){
        return "Polteageist";
    }

    public String nameOfSet(){
        return "Polteageist";
    }

    public String set(){
       return "https://pokepast.es/d61ae51b2a25cd8d";
    }

    public String description(){
        return "Polteageist is essentially half the reason you’re running Psychic Terrain in the first place. At first glance it may seem like an unsuspecting Pokemon with two pretty solid stats followed by four other mediocre to decent stats at best. However, upon further inspection it has access to two insanely powerful attacks. The first of which is arguably the strongest boosting attack in the game, Shell Smash. Shell Smash boosts the user’s Attack, Special Attack, and Speed by two stages, at the cost of lowering its Defense and Special Defense by one stage each. Polteageist is a pretty frail Pokemon anyways, so we don’t really care about this downside. The other powerful attack Polteageist has access to is Stored Power. Beginning at Base 20 Power, you’re probably thinking I’m a liar and are questioning what I’m even talking about. However, Stored Power gains 20 Base Power for each stage each of the user’s stats are raised. Meaning after just one Shell Smash, Stored Power hits a staggering 140 Base Power, which is also boosted by Psychic Terrain, and now is backed by Polteageist’s now +2 Special Attack. With the Focus Sash, provided that Polteageist did not suffer any chip damage, it can not be one hit KO’d by any attack that is not a multi-hit, and with Psychic Terrain up your opponent cannot target it with any priority attacks such as Bullet Punch, Aqua Jet, Sucker Punch, and more. Against an unprepared team and considering that you’ve set up your Psychic Terrain properly, Polteageist can absolutely rip through most defensive cores, even if they are packing any Unaware Pokemon that ignore its stat boosts. It is highly recommended that you save your Terastallization for Polteageist so it can either Tera Fighting or Fairy so it has coverage for any Dark Types that would resist Shadow Ball and be immune to Stored Power.";
    }
 }