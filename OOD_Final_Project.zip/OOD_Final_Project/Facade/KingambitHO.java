/*
 * Jonathan Nushi
 */

 class KingambitHO implements Pokemon{
    public String name(){
        return "Kingambit";
    }

    public String nameOfSet(){
        return "Kingambit";
    }

    public String set(){
       return "https://pokepast.es/3d7dafb58e52119c";
    }

    public String description(){
        return "Kingambit is an extremely bulky and powerful Physical attacker that necessitates very specific answers from your opponent. Its ability, Supreme Overlord, gives Kingambit a 1.1x boost in its attack for each of its teammates that have fainted in battle, meaning that if Kingambit is your last Pokemon it receives a 1.5x boost in attack right off the bat, which can be even further boosted by Swords Dance. While it is rather slow, Sucker Punch remedies this problem, as it always strikes first if your opponent selected a direct Attack on the turn you use it. With its impressive bulk, Supreme Overlord, insanely high Attack, solid defensive and offensive Steel/Dark typing, and the threat of Sucker Punch, Kingambit is an extremely dangerous late game threat and prime user of Terastallization. With Terastallization, Kingambit can either use Tera Dark in order to make Sucker Punch and Kowtow Cleave even harder to survive than they already are. Tera Flying remedies its 2x and 4x Ground and Fighting weaknesses, making it an amazing against Great Tusk, as most Great Tusk sets choose not to run coverage for Flying Types unless their teams desperately need it. While Tera Fire is a more niche pick that makes it immune to being burned by Will-o-Wisp and other effects that can burn Kingambit, as well as turning its 2x Fire weakness into a resistance, making Kingambit a very solid answer to Volcarona and Skeledirge. Being the second most common Pokemon in the meta game, as well as a very likely candidate for Terastallization, Kingambit is yet another Pokemon that you should expect to run into while playing, and absolutely must account for while team building.";
    }
 }