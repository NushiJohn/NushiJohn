/*
 * Jonathan Nushi
 */

 class WalkingWake implements Pokemon{
    public String name(){
        return "Walking Wake";
    }

    public String nameOfSet(){
        return "Walking Wake";
    }

    public String set(){
       return "https://pokepast.es/426626c20c634212";
    }

    public String description(){
        return "Choice Specs Walking Wake is one of the most dangerous Pokemon in the meta game and is almost a must-have for any Sun team. Its Water/Dragon Typing allows it to switch on most opposing Water and Fire Type attacks trying to either counter your Water-weak Pokemon or take advantage of the Sun that you took so much effort to set up, as Walking Wake takes 0.25x damage from both types. Adding a Water Type to a Sun team may seem counterintuitive at first, however, Walking Wake has two extremely attractive qualities that are included with Sun in mind. The first is its ability Protosynthesis, which at this point in the program you have likely read up on from the Roaring Moon entry. Although in case you haven’t: Photosynthesis boosts Walking Wake’s highest stat by 1.3x (or 1.5x if its Speed stat is being boosted) if the Sun weather condition is in effect. Normally the Booster Energy item is used to proc this effect outside of the Sun, however, the downside to this is that the Booster Energy is a consumable one-use item that wears off after switching out. The second quality is Walking Wake’s signature attack Hydro Steam, a Base 80 Water Type attack that gets its power boosted by 1.5x in the Sun as opposed to being lowered by 0.5x. With Protosynthesis boosting Walking Wake’s Speed in the Sun, Choice Specs boosting its already high Special Attack even higher, and the combination of Hydro Steam, Draco Meteor, and Flamethrower; only a very particular set of Pokemon can expect to survive one, let alone two, attacks from Walking Wake and hope to KO or weaken it in return. Many Sun team strategies revolve around maintaining Sun for as long as possible, removing Walking Wake’s few counters from play, and finding as many opportunities as possible to get Walking Wake into battle and let its attacks off.        ";
    }
 }