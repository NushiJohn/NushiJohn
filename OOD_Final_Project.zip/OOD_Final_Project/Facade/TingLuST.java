/*
 * Jonathan Nushi
 */

 class TingLuST implements Pokemon{
    public String name(){
        return "Ting-Lu";
    }

    public String nameOfSet(){
        return "Ting Lu";
    }

    public String set(){
       return "https://pokepast.es/6eb2f30862a0d61b";
    }

    public String description(){
        return "Ting-Lu is an impressively bulky hazard setter that can also dish out consistent damage with Ruination, which cuts its opponents current HP in half. Ting-Lu naturally has impressive physical bulk, and its ability, Vessel of Ruin, contributes to its Special bulk by reducing its opponent’s Special Attack by 3/4. Ting-Lu’s only downfall is that it has no attack that restores its HP, but aside from that it is absurdly bulky and is sure to get some hazards on the field and deal solid damage itself after the fact.";
    }
 }