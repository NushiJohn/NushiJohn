/*
 * Jonathan Nushi
 */
 class GholdengoBA2 implements Pokemon{
    public String name(){
        return "Gholdengo";
    }

    public String nameOfSet(){
        return "Gholdengo set 2";
    }

    public String set(){
       return "https://pokepast.es/bdc8b5e5f927064c";
    }

    public String description(){
        return "This Gholdengo set is specifically made to counter and set up on Garganacl. Thanks to the Covert Cloak item, Garganacl’s Salt Cure attack’s secondary effect of passive damage does not affect Gholdengo, allowing it to switch for free and set up on any Garganacl that is not running Earthquake, which is a vast majority of Garganacls.";
    }
 }