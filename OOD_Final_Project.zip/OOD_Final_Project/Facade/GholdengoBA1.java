/*
 * Jonathan Nushi
 */
class GholdengoBA1 implements Pokemon{
    public String name(){
        return "Gholdengo";
    }

    public String nameOfSet(){
        return "Gholdengo set 1";
    }

    public String set(){
       return "https://pokepast.es/0b94653cdfd58d3a";
    }

    public String description(){
        return "Gholdengo is frequently paired with Glimmora and other Pokemon that set up multiple hazards thanks to its Good as Gold ability in tandem with its typing. Its Steel/Ghost typing grants it immunity to Rapid Spin and Mortal Spin, and Good as Gold prevents Defog from removing hazards as well. These two traits allow it to block a majority of hazard removal in the meta, and thanks to its stats and amazing typing it can be immediately threatening once it switches in on a hazard removal attempt, which greatly complement its high Special Attack  and powerful signature attack, Make It Rain. Ghost/Steel is also a type combination that hits several Pokemon for at least neutral damage, making it fairly difficult to switch into for some teams.";
    }
 }