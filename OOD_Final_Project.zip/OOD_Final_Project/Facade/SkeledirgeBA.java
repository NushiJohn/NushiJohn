/*
 * Jonathan Nushi
 */
class SkeledirgeBA implements Pokemon{
    public String name(){
        return "Skeledirge";
    }

    public String nameOfSet(){
        return "Skeledirge";
    }

    public String set(){
       return "https://pokepast.es/97bdca464b0e3c6b";
    }

    public String description(){
        return "Skeledirge is a very reliable defensive check to many set up sweepers in the tier thanks to its Unaware ability. Unaware ignores the stat changes of the opponent, meaning that any stat boosts are completely meaningless in the face of Skeledirge. Complemented with solid bulk and the ability to burn opponents with Will-O-Wisp (which halves the damage of physical attacks), Skeledirge can safely come in on many set up sweepers and render them almost useless for the rest of the game. In addition to these already desirable qualities, Skeledirge also has a very powerful signature attack in the form of Torch Song, which is a Base 80 Power Fire Type attack that boosts Skeledirge’s Special Attack by one stage every time that it’s used. So while Skeledirge’s opposition is unable to boost their stats, Skeledirge can quickly boost its own Special Attack while attacking at the same time. Not to mention it also has longevity thanks to Slack Off, which restores half of its max HP. While its Fire/Ghost Typing has a solid enough defensive niche, Skeledirge is one of the most frequent users of Terastallization so that it may take advantage of the few weaknesses that mono Fairy or Water types enjoy.";
    }
 }