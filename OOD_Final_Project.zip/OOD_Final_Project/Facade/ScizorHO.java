/*
 * Jonathan Nushi
 */

 class ScizorHO implements Pokemon{
    public String name(){
        return "Scizor";
    }

    public String nameOfSet(){
        return "Scizor";
    }

    public String set(){
       return "https://pokepast.es/49fbd0a71ebb0049";
    }

    public String description(){
        return "Scizor is a useful bulky offensive pivot with access to strong priority in the form of Technician Bullet Punch. Technician boosts the power of any move under 60 Base Power by 1.5x, bringing Bullet Punch’s 40 Base Power to a decent 60, which is further boosted to a Base 90 thanks to its natural STAB boost. Bullet Punch compensates for its low power by always striking first, which is very handy since Scizor is naturally slow but has a commendable high Attack stat that it can boost via Swords Dance. For most of the game, Scizor will be coming in on a resisted attack on a target that it will scare out either due to the fact that they don’t have the coverage or sheer power to blow over Scizor, or due to the fact that they would get dropped by Bullet Punch or Close Combat. So, Scizor can anticipate this switch and click U-turn on the switch so that you may bring in your check to whatever they brought out to deal with Scizor. Scizor has solid bulk, only one 4x weakness to Fire, an immunity to Poison so it cannot be worn down by the Poison Status, and a respectable 8 Resistances so it can at least survive one attack from most Pokemon and threaten them with Bullet Punch in return. If you enjoy Pokemon that allow you to retain momentum in the form of pivoting attacks such as U-turn paired with solid bulk, while also being able to overcome your opponent’s fastest threats regardless of how fast they are; Scizor is one of the very few Pokemon that can fit this role well.";
    }
 }