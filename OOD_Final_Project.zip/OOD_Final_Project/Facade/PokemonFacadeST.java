/*
 * Jonathan Nushi
 */
import java.util.*;

public class PokemonFacadeST{
    private Pokemon gholdengoST;
    private Pokemon clodsireST;
    private Pokemon dondozoST;
    private Pokemon garganaclST;
    private Pokemon talonflame;
    private Pokemon tingLuST;
    private Pokemon alomomola;
    private Pokemon dragapultST1;
    private Pokemon dragapultST2;

    public PokemonFacadeST(){
        gholdengoST = new GholdengoST();
        clodsireST = new ClosdireST();
        dondozoST = new DondozoST();
        garganaclST = new GarganaclST();
        talonflame = new Talonflame();
        tingLuST = new TingLuST();
        alomomola = new Alomomola();
        dragapultST1 = new DragapultST1();
        dragapultST2 = new DragapultST2();
    }

    ArrayList<String> names = new ArrayList<String>();
    public void populateSTNames(){
        names.add(gholdengoST.nameOfSet());
        names.add(clodsireST.nameOfSet());
        names.add(dondozoST.nameOfSet());
        names.add(garganaclST.nameOfSet());
        names.add(talonflame.nameOfSet());
        names.add(tingLuST.nameOfSet());
        names.add(alomomola.nameOfSet());
    }

    public ArrayList<String> displaySTNames(){
        return (names);
    }

    public void populateSTThreatNames(){
        names.add(dragapultST1.nameOfSet());
        names.add(dragapultST2.nameOfSet());
    }


    public String gholdengoSTSet(){
        return gholdengoST.set();
    }
     
    public String gholdengoSTName(){
        return gholdengoST.name();
    }

    public String gholdengoSTNameOfSet(){
        return gholdengoST.nameOfSet();
    }
    
    public String gholdengoSTDescription(){
        return gholdengoST.description();
    }



    public String clodsireSTSet(){
        return clodsireST.set();
    }
     
    public String clodsireSTName(){
        return clodsireST.name();
    }

    public String clodsireSTNameOfSet(){
        return clodsireST.nameOfSet();
    }
    
    public String clodsireSTDescription(){
        return clodsireST.description();
    }



    public String dondozoSTSet(){
        return dondozoST.set();
    }
     
    public String dondozoSTName(){
        return dondozoST.name();
    }

    public String dondozoSTNameOfSet(){
        return dondozoST.nameOfSet();
    }
    
    public String dondozoSTDescription(){
        return dondozoST.description();
    }



    public String garganaclSTSet(){
        return garganaclST.set();
    }
     
    public String garganaclSTName(){
        return garganaclST.name();
    }

    public String garganaclSTNameOfSet(){
        return garganaclST.nameOfSet();
    }
    
    public String garganaclSTDescription(){
        return garganaclST.description();
    }



    public String talonflameSet(){
        return talonflame.set();
    }
     
    public String talonflameName(){
        return talonflame.name();
    }

    public String talonflameNameOfSet(){
        return talonflame.nameOfSet();
    }
    
    public String talonflameDescription(){
        return talonflame.description();
    }



    public String tingLuSTSet(){
        return tingLuST.set();
    }
     
    public String tingLuSTName(){
        return tingLuST.name();
    }

    public String tingLuSTNameOfSet(){
        return tingLuST.nameOfSet();
    }
    
    public String tingLuSTDescription(){
        return tingLuST.description();
    }


    
    public String alomomolaSet(){
        return alomomola.set();
    }
     
    public String alomomolaName(){
        return alomomola.name();
    }

    public String alomomolaNameOfSet(){
        return alomomola.nameOfSet();
    }
    
    public String alomomolaDescription(){
        return alomomola.description();
    }



    public String dragapultST1Set(){
        return dragapultST1.set();
    }
     
    public String dragapultST1Name(){
        return dragapultST1.name();
    }

    public String dragapultST1NameOfSet(){
        return dragapultST1.nameOfSet();
    }
    
    public String dragapultST1Description(){
        return dragapultST1.description();
    }



    public String dragapultST2Set(){
        return dragapultST2.set();
    }
     
    public String dragapultST2Name(){
        return dragapultST2.name();
    }

    public String dragapultST2NameOfSet(){
        return dragapultST2.nameOfSet();
    }
    
    public String dragapultST2Description(){
        return dragapultST2.description();
    }
}