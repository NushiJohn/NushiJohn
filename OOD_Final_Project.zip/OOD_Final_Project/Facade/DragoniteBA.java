/*
 * Jonathan Nushi
 */
class DragoniteBA implements Pokemon{
    public String name(){
        return "Dragonite";
    }

    public String nameOfSet(){
        return "Dragonite";
    }

    public String set(){
       return "https://pokepast.es/39a8b6d29f7fb9f8";
    }

    public String description(){
        return "Dragonite is a powerful mid to late game sweeper that can easily snowball out of control and secure a win. Its multiscale ability halves the damage of an attack that Dragonite takes while it is at full health, allowing it to safely set up Dragon Dances to boost its Attack and Speed by one stage each and position itself for a sweep. Roost allows it to heal back up to full health in order to avoid being revenge KO’d and continue abusing Multiscale’s damage resistance, and Heavy-Duty Boots are necessary in order to avoid Stealth Rock damage and preserve Multiscale upon switching in. Its Dragon / Flying typing, solid bulk, and Multiscale allow it to come in safely on a vast majority of attacks in the meta game and begin its gameplan. Thanks to its overreliance on setting up, Dragonite can be hard countered by Unaware Pokemon or Pokemon that are bulky enough to survive one boosted attack and status Dragonite in return.";
    }
 }