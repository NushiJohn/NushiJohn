/*
 * Jonathan Nushi
 */

class GholdengoST implements Pokemon{
    public String name(){
        return "Gholdengo";
    }

    public String nameOfSet(){
        return "Gholdengo";
    }

    public String set(){
       return "https://pokepast.es/17a9f224bc72122b";
    }

    public String description(){
        return "While Gholdengo’s stats may suggest that it is more inclined to deal damage rather than be a defensive staple, its Ghost/Steel type combination and Good as Gold ability are both invaluable for most teams. Ghost/Steel resists several different types and is immune to a whopping three types. Meanwhile, Good as Gold makes Gholdengo completely immune to any status attack directed at it. These two traits mean that Gholdengo is completely immune to a vast majority of hazard removal attacks, barring a very select few. This is crucial for Stall strategies that focus on dealing indirect damage via the usage of hazards, which include the moves: Stealth Rocks, Spikes, and occasionally Toxic Spikes.";
    }
 }