/*
 * Jonathan Nushi
 */
class RotomWashBA1 implements Pokemon{
    public String name(){
        return "Rotom-Wash";
    }

    public String nameOfSet(){
        return "Rotom Wash set 1";
    }

    public String set(){
       return "https://pokepast.es/47f8c7517404d4e7";
    }

    public String description(){
        return "Rotom is a very useful defensive pivot that can survive attacks from several different threats in the meta game, and either status them or switch a teammate in safely with Volt Switch. With uninvested Speed, Rotom is a relatively slower Volt Switch user. This is a very desirable quality because Rotom can tank a hit from an opponent who decides to stay in on Rotom, and then Rotom can switch in a teammate who can appropriately deal with whatever Pokemon it Volt Switched on.";
    }
 }