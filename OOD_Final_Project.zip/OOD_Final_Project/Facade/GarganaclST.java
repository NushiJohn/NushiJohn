/*
 * Jonathan Nushi
 */

 class GarganaclST implements Pokemon{
    public String name(){
        return "Garganacl";
    }

    public String nameOfSet(){
        return "Garganacl";
    }

    public String set(){
       return "https://pokepast.es/5a79d46f1f861650";
    }

    public String description(){
        return "Garganacl is one of the bulkiest Pokemon on both the  Physical and Special sides of the spectrum. With an astounding 100/130/90 bulk, very few Pokemon can hope to one hit KO it. In addition to this, its signature move Salt Cure is probably the best move a Pokemon of its archetype could ever possibly hope for. Salt Cure is a Base 40 attack which damages 12% of the target’s max HP at the end of every turn until the switch out, or 25% if they are a Steel or Water type. This damage persists even if Garganacl switches out. Garganacl also has a powerful ability in Purifying Salt which grants it a resistance to Ghost Type attacks, and makes it completely immune to Status effects, meaning it cannot be worn down by Poison or Burn. Between its impressive bulk, its access to Recover, Purifying Salt, and Salt Cure’s powerful residual damage, Garganacl is one of the most powerful bulky walls a team could ask for.";
    }
 }