/*
 * Jonathan Nushi
 */

 class RoaringMoon implements Pokemon{
    public String name(){
        return "Roaring Moon";
    }

    public String nameOfSet(){
        return "Roaring Moon";
    }

    public String set(){
       return "https://pokepast.es/8587b93dd7ddd8b5";
    }

    public String description(){
        return "The Choice Band variant of Roaring Moon is generally only seen on Sun teams, hence why it is only being recommended if you’re adding a Torkoal onto your team. That being said, thanks to Protosynthesis, Roaring Moon is effectively both Choice Banded and Scarfed when the Sun is up, so if your opponent is poorly positioning themselves then Roaring Moon can rack some serious damage for free. Most of the time you will find yourself clicking U-turn until their switch-ins for Roaring Moon have either been knocked out or brought down to low enough HP that Roaring Moon can secure the KO itself. Of course this is perfectly fine because U-turn will allow you to bring in Roaring Moon’s teammates that will also take advantage of the Sun in order to overwhelm your opponent’s defensive responses.";
    }
 }