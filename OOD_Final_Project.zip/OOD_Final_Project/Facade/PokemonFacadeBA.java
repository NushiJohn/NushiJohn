/*
 * Jonathan Nushi
 */
import java.util.*;

 public class PokemonFacadeBA{
    private Pokemon gholdengoBA1;
    private Pokemon gholdengoBA2;
    private Pokemon gholdengoBA3;
    private Pokemon skeledirgeBA;
    private Pokemon rotomWashBA1;
    private Pokemon rotomWashBA2;
    private Pokemon greatTuskBA1;
    private Pokemon greatTuskBA2;
    private Pokemon clodsireBA;
    private Pokemon dragoniteBA;



    public PokemonFacadeBA(){
        gholdengoBA1 = new GholdengoBA1();
        gholdengoBA2 = new GholdengoBA2();
        gholdengoBA3 = new GholdengoBA3();
        skeledirgeBA = new SkeledirgeBA();
        rotomWashBA1 = new RotomWashBA1();
        rotomWashBA2 = new RotomWashBA2();
        greatTuskBA1 = new GreatTuskBA1();
        greatTuskBA2 = new GreatTuskBA2();
        clodsireBA = new ClodsireBA();
        dragoniteBA = new DragoniteBA();
    }
    
    ArrayList<String> names = new ArrayList<String>();
    public void populateBANames(){
        names.add(gholdengoBA1.nameOfSet());
        names.add(gholdengoBA2.nameOfSet());
        names.add(gholdengoBA3.nameOfSet());
        names.add(skeledirgeBA.nameOfSet());
        names.add(rotomWashBA1.nameOfSet());
        names.add(rotomWashBA2.nameOfSet());
        names.add(greatTuskBA1.nameOfSet());
        names.add(greatTuskBA2.nameOfSet());
        names.add(clodsireBA.nameOfSet());
        names.add(dragoniteBA.nameOfSet());
    }

    public ArrayList<String> displayBANames(){
        return (names);
    }


    public String gholdengoBA1Set(){
        return gholdengoBA1.set();
    }

    public String gholdengoBA1Name(){
        return gholdengoBA1.name();
    }

    public String gholdengoBA1SetName(){
        return gholdengoBA1.nameOfSet();
    }
    
    public String gholdengoBA1Description(){
        return gholdengoBA1.description();
    }



    public String gholdengoBA2Set(){
        return gholdengoBA2.set();
    }

    public String gholdengoBA2Name(){
        return gholdengoBA2.name();
    }

    public String gholdengoBA2SetName(){
        return gholdengoBA2.nameOfSet();
    }
    
    public String gholdengoBA2Description(){
        return gholdengoBA2.description();
    }



    public String gholdengoBA3Set(){
        return gholdengoBA3.set();
    }

    public String gholdengoBA3Name(){
        return gholdengoBA3.name();
    }

    public String gholdengoBA3SetName(){
        return gholdengoBA3.nameOfSet();
    }
    
    public String gholdengoBA3Description(){
        return gholdengoBA3.description();
    }



    public String skeledirgeBASet(){
        return skeledirgeBA.set();
    }

    public String skeledirgeBAName(){
        return skeledirgeBA.name();
    }

    public String skeledirgeBASetName(){
        return skeledirgeBA.nameOfSet();
    }
    
    public String skeledirgeBADescription(){
        return skeledirgeBA.description();
    }



    public String rotomWashBA1Set(){
        return rotomWashBA1.set();
    }

    public String rotomWashBA1Name(){
        return rotomWashBA1.name();
    }

    public String rotomWashBA1SetName(){
        return rotomWashBA1.nameOfSet();
    }
    
    public String rotomWashBA1Description(){
        return rotomWashBA1.description();
    }



    public String rotomWashBA2Set(){
        return rotomWashBA2.set();
    }

    public String rotomWashBA2Name(){
        return rotomWashBA2.name();
    }

    public String rotomWashBA2SetName(){
        return rotomWashBA2.nameOfSet();
    }
    
    public String rotomWashBA2Description(){
        return rotomWashBA2.description();
    }



    public String greatTuskBA1Set(){
        return greatTuskBA1.set();
    }

    public String greatTuskBA1Name(){
        return greatTuskBA1.name();
    }

    public String greatTuskBA1SetName(){
        return greatTuskBA1.nameOfSet();
    }
    
    public String greatTuskBA1Description(){
        return greatTuskBA1.description();
    }



    public String greatTuskBA2Set(){
        return greatTuskBA2.set();
    }

    public String greatTuskBA2Name(){
        return greatTuskBA2.name();
    }

    public String greatTuskBA2SetName(){
        return greatTuskBA2.nameOfSet();
    }
    
    public String greatTuskBA2Description(){
        return greatTuskBA2.description();
    }



    public String clodsireBASet(){
        return clodsireBA.set();
    }

    public String clodsireBAName(){
        return clodsireBA.name();
    }

    public String clodsireBASetName(){
        return clodsireBA.nameOfSet();
    }
    
    public String clodsireBADescription(){
        return clodsireBA.description();
    }



    public String dragoniteBASet(){
        return dragoniteBA.set();
    }

    public String dragoniteBAName(){
        return dragoniteBA.name();
    }

    public String dragoniteBASetName(){
        return dragoniteBA.nameOfSet();
    }
    
    public String dragoniteBADescription(){
        return dragoniteBA.description();
    }
}