/*
 * Jonathan Nushi
 */
class GholdengoBA3 implements Pokemon{
    public String name(){
        return "Gholdengo";
    }

    public String nameOfSet(){
        return "Gholdengo set 3";
    }

    public String set(){
       return "https://pokepast.es/027490aed403f1fd";
    }

    public String description(){
        return "Similar to the Covert Cloak set, except with a focus on switching in on Great Tusk (most of the time) instead. Thanks to Gholdengo’s Ghost typing, when equipped with an Air Balloon it is completely immune to Great Tusk’s STAB combination, however, it still must be wary of Knock Off. Unless Great Tusk’s attack is boosted in some way, Gholdengo should always be able to survive one Knock Off, allowing it to smack Great Tusk with a powerful Make It Rain which can severely weaken it and allow a teammate to knock it out. Of course, you must be careful of switching in in a situation where your opponent might just click Knock Off anyways, or is trying to hard predict you switching in your Gholdeng. However the very existence of having Air Balloon Gholdengo in the back can make your opponent second guess clicking Close Combat or Headlong Rush in a situation where they would otherwise be able to do so without a second thought.";
    }
 }