/*
 * Jonathan Nushi
 */

 class Talonflame implements Pokemon{
    public String name(){
        return "Talonflame";
    }

    public String nameOfSet(){
        return "Talonflame";
    }

    public String set(){
       return "https://pokepast.es/174e24760fda412f";
    }

    public String description(){
        return "Talonflame is a fast support Pokemon that focuses on removing hazards via Defog and spreading Burn via Will-O-Wisp and Flame Body, the ladder of which has a 30% chance of Burning the attacker if they make physical contact with Talonflame. Burn halves the damage from Physical attackers, which is particularly useful for bolstering the Physical Defense of your other walls. Talonflame matches up particularly well into Great Tusk, as extremely few Great Tusk variants run Rock Type coverage, and most of their attacks make physical contact. If you need a dedicated Defogger and have a problem with Great Tusk removing key components of your Stall team, Talonflame is a great answer for this issue.";
    }
 }