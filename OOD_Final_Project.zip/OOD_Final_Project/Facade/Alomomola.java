/*
 * Jonathan Nushi
 */

 class Alomomola implements Pokemon{
    public String name(){
        return "Alomomola";
    }

    public String nameOfSet(){
        return "Alomomola";
    }

    public String set(){
       return "https://pokepast.es/db52a4a2e903cb40";
    }

    public String description(){
        return "Alomomola has an impressive HP stat and decent Defenses, but it still is able to fulfill a useful niche for any Stall team. Wish is a move that heals either Alomomola or a teammate who has switched in by half of Alomomola’s HP on the turn after it has been used, and since Alomomola has a relatively high HP stat, an Alomomola Wish can often fully heal most other Pokemon, even on Stall teams. Additionally, Whirlpool traps the opponent for 4-5 turns and deals 1/8 of their max HP at the end of each turn. Generally, Alomomola traps a specific Pokemon that struggles with taking it out, healing itself in the process with Wish and Protect, and then when Whirlpool is about to run out it often uses Wish again and switches to a teammate that can survive one more attack and then be healed after the fact. If your team consists of Pokemon that struggle with sustaining themselves, Alomomola can help resolve this issue.";
    }
 }