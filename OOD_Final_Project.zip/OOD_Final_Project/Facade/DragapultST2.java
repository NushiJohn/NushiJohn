/*
 * Jonathan Nushi
 */

 class DragapultST2 implements Pokemon{
    public String name(){
        return "Dragapult";
    }

    public String nameOfSet(){
        return "Dragapult set 2";
    }

    public String set(){
       return "https://pokepast.es/0119b3a31fa0f37a";
    }

    public String description(){
        return "Dragapult is one of the fastest Pokemon in the meta game, and unchecked can get off huge amounts of damage on the opponent’s team if they are not prepared with the proper switch-ins. The scariest aspect of Dragapult is that it is powerful on both the physical and special spectrums; both of which have widely different answers. Thanks to its flexibility and Dragapult’s high speed, it can wreak havoc on your opponent’s team before they even know which set you’re running, and by the time they figure that out it may already be too late for them to properly answer it.";
    }
 }