/*
 * Jonathan Nushi
 */
class RotomWashBA2 implements Pokemon{
    public String name(){
        return "Rotom-Wash";
    }

    public String nameOfSet(){
        return "Rotom Wash set 2";
    }

    public String set(){
       return "https://pokepast.es/f06562e826583269";
    }

    public String description(){
        return "Choice Scarf Rotom is extremely similar in functionality to the standard Leftovers set, however, it has an additional utility in being able to Trick its Choice Scarf onto a dedicated bulky wall such as Garganacl, Skeledirge, Dondozo, and so on; locking them into one move every time they switch and severely hampering their functionality.";
    }
 }