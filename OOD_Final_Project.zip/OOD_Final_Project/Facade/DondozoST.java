/*
 * Jonathan Nushi
 */

 class DondozoST implements Pokemon{
    public String name(){
        return "Dondozo";
    }

    public String nameOfSet(){
        return "Dondozo";
    }

    public String set(){
       return "https://pokepast.es/230ec23f4c72973f";
    }

    public String description(){
        return "Dondozo is one of the most Physically bulky Pokemon in the entire game. Its impressive natural bulk is complemented by Unaware, which ignores the opponent’s stat boosts. So, Dondozo is able to stack its own stat boosts while the opponent must rely on alternative methods to handle it. Rest fully restores Dondozo’s HP at the cost of putting it to sleep for 2 turns. However, during one of these turns Dondozo may use Sleep Talk, which randomly selects one of its other moves while Dondozo is asleep. If you need a dedicated Unaware wall that sits around and accumulates stat boosts, Dondozo is your pick.";
    }
 }