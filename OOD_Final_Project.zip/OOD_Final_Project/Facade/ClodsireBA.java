/*
 * Jonathan Nushi
 */
class ClodsireBA implements Pokemon{
    public String name(){
        return "Clodsire";
    }

    public String nameOfSet(){
        return "Clodsire";
    }

    public String set(){
       return "https://pokepast.es/ae64e17839c7e0b1";
    }

    public String description(){
        return "Clodsire is one of the most stable Specially Defensive walls in the meta game, seemingly holding the tier together whenever a Specially Offensive threat is out of control. Clodsire has two great Defensive abilities. First is Water Absorb which turns its Water weakness into an immunity, and even heals Clodsire for a quarter of its max HP whenever it is hit by a Water Type attack. The second is Unaware which ignores the stat changes of its opponent, meaning Clodsire can come in on a set up sweeper and threaten them with Toxic and begin setting up its hazards. It also inherently has more longevity than most other Pokemon because it has Recover which restores half of its max HP, and is a Poison Type so it cannot be Poisoned (unless it Terastallizes). If you feel that your team is lacking defensively on the Special side and are also looking for hazards and residual damage via Toxic, then Clodsire is a very suitable choice.";
    }
}
