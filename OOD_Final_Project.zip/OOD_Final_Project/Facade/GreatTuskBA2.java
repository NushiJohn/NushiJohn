/*
 * Jonathan Nushi
 */
class GreatTuskBA2 implements Pokemon{
    public String name(){
        return "Great Tusk";
    }

    public String nameOfSet(){
        return "Great Tusk set 2";
    }

    public String set(){
       return "https://pokepast.es/df240736f36ac421";
    }

    public String description(){
        return "Great Tusk is an incredible offensive and defensive behemoth that fits on pretty much any kind of team. Its physical bulk makes it extremely difficult to OHKO with neutral physical attacks. This, paired with its diverse movepool, extremely high attack stat, very solid speed stat that can be boosted with Rapid Spin, as well as incredible neutral coverage in its Fighting/Ground typing make it a volatile threat that any team has to consider dealing with. It can run a large number sets with several different items, Tera Types, EV investments, and attacks in order to accommodate pretty much whatever its team needs. It has been considered the number one Pokemon in the current meta game for several months now to the point where over half of teams on the ladder include it. You will run into it while playing, and you must know how to counter it.";
    }
 }