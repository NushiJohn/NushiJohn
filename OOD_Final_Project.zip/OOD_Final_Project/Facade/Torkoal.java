/*
 * Jonathan Nushi
 */

 class Torkoal implements Pokemon{
    public String name(){
        return "Torkoal";
    }

    public String nameOfSet(){
        return "Torkoal";
    }

    public String set(){
       return "https://pokepast.es/14b41d4104e4a741";
    }

    public String description(){
        return "Torkoal is a slow, physically bulky, weak Pokemon; so you may be wondering why I’m recommending you add it to your Hyper Offensive team. Torkoal has the unique ability to facilitate one of the strongest Hyper Offensive strategies in the game, Hyper Offensive Sun. Its Drought ability activates the Sun weather condition for five turns upon switching in, or eight turns if Torkoal is holding the Heat Rock item. The Sun weather condition has a bevy of effects on the battle including: strengthening Fire Type attacks by 1.5x, weakening Water Type attacks by 0.5x, allowing Solar Beam and Solar Blade to activate without needing a turn to charge (giving many Fire Type Pokemon very handy Grass Type coverage for the Water and Rock Types that wall them), and activating abilities such as Chlorophyll, Solar Power, Harvest, and Protosynthesis that have powerful stat-raising effects. Adding Torkoal to your team will make the program begin to suggest other Pokemon and sets that are exclusive to Sun teams for the positive effects listed above, or because they directly support the strategy and its longevity. Torkoal itself is generally considered a bad Pokemon, before it received the Drought ability it has ended up in either the lowest or second lowest usage tier in every single Generation since its introduction in Generation 3. However, ever since it received Drought in Generation 8 it has seen at least some form of success in OU thanks to the sole fact that it sets up Sun just for simply existing. Prior to Generation 8, the only non-Ubers Pokemon that had access to Drought was Ninetales, another historically weak Pokemon, and as soon as Torkoal received the ability Ninetales immediately stopped seeing any form of play on Sun teams in tiers that allowed the strategy, because Torkoal was just marginally stronger than Ninetales thanks to its higher bulk and better utility, which is a testament to how little the Pokemon wielding Drought matters, so long as they are able to come into play at least a few times a game.";
    }
 }