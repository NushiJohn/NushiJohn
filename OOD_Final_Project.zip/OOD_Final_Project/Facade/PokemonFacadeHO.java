/*
 * Jonathan Nushi
 */
import java.util.*;
public class PokemonFacadeHO{
    private Pokemon gholdengoHO;
    private Pokemon torkoal;
    private Pokemon walkingWake;
    private Pokemon indeedee;
    private Pokemon polteageist;
    private Pokemon armarouge;
    private Pokemon roaringMoon;
    private Pokemon greninja;
    private Pokemon cinderace;
    private Pokemon kingambitHO;
    private Pokemon scizorHO;



    public PokemonFacadeHO(){
        gholdengoHO = new GholdengoHO();
        torkoal = new Torkoal();
        walkingWake = new WalkingWake();
        indeedee = new Indeedee();
        polteageist = new Polteageist();
        armarouge = new Armarouge();
        roaringMoon = new RoaringMoon();
        greninja = new Greninja();
        cinderace = new Cinderace();
        kingambitHO = new KingambitHO();
        scizorHO = new ScizorHO();
    }
    
    ArrayList<String> names = new ArrayList<String>();
    public void populateHONames(){
        names.add(gholdengoHO.nameOfSet());
        names.add(torkoal.nameOfSet());
        names.add(indeedee.nameOfSet());
        names.add(greninja.nameOfSet());
        names.add(cinderace.nameOfSet());
        names.add(kingambitHO.nameOfSet());
        names.add(scizorHO.nameOfSet());
    }

    public ArrayList<String> displayHONames(){
        return (names);
    }

    public void populateHOSunNames(){
        names.add(walkingWake.nameOfSet());
        names.add(roaringMoon.nameOfSet());
    }

    public void populateHOPTNames(){
        names.add(polteageist.nameOfSet());
        names.add(armarouge.nameOfSet());
    }


    public String gholdengoHOSet(){
        return gholdengoHO.set();
    }

    public String gholdengoHOName(){
        return gholdengoHO.name();
    }

    public String gholdengoHOSetName(){
        return gholdengoHO.nameOfSet();
    }
     
    public String gholdengoHODescription(){
        return gholdengoHO.description();
    }    



    public String torkoalSet(){
        return torkoal.set();
    }

    public String torkoalName(){
        return torkoal.name();
    }

    public String torkoalSetName(){
        return torkoal.nameOfSet();
    }
     
    public String torkoalDescription(){
        return torkoal.description();
    }    


    
    public String walkingWakeSet(){
        return walkingWake.set();
    }

    public String walkingWakeName(){
        return walkingWake.name();
    }

    public String walkingWakeSetName(){
        return walkingWake.nameOfSet();
    }
     
    public String walkingWakeDescription(){
        return walkingWake.description();
    }    



    public String indeedeeSet(){
        return indeedee.set();
    }

    public String indeedeeName(){
        return indeedee.name();
    }

    public String indeedeeSetName(){
        return indeedee.nameOfSet();
    }
     
    public String indeedeeDescription(){
        return indeedee.description();
    }    



    public String polteageistSet(){
        return polteageist.set();
    }

    public String polteageistName(){
        return polteageist.name();
    }

    public String polteageistSetName(){
        return polteageist.nameOfSet();
    }
     
    public String polteageistDescription(){
        return polteageist.description();
    }    



    
    public String armarougeSet(){
        return armarouge.set();
    }

    public String armarougeName(){
        return armarouge.name();
    }

    public String armarougeSetName(){
        return armarouge.nameOfSet();
    }
     
    public String armarougeDescription(){
        return armarouge.description();
    }



    public String roaringMoonSet(){
        return roaringMoon.set();
    }

    public String roaringMoonName(){
        return roaringMoon.name();
    }

    public String roaringMoonSetName(){
        return roaringMoon.nameOfSet();
    }
     
    public String roaringMoonDescription(){
        return roaringMoon.description();
    }


    
    public String greninjaSet(){
        return greninja.set();
    }

    public String greninjaName(){
        return greninja.name();
    }

    public String greninjaSetName(){
        return greninja.nameOfSet();
    }
     
    public String greninjaDescription(){
        return greninja.description();
    }



    public String cinderaceSet(){
        return cinderace.set();
    }

    public String cinderaceName(){
        return cinderace.name();
    }

    public String cinderaceSetName(){
        return cinderace.nameOfSet();
    }
     
    public String cinderaceDescription(){
        return cinderace.description();
    }



    public String kingambitHOSet(){
        return kingambitHO.set();
    }

    public String kingambitHOName(){
        return kingambitHO.name();
    }

    public String kingambitHOSetName(){
        return kingambitHO.nameOfSet();
    }
     
    public String kingambitHODescription(){
        return kingambitHO.description();
    }



    public String scizorHOSet(){
        return scizorHO.set();
    }

    public String scizorHOName(){
        return scizorHO.name();
    }

    public String scizorHOSetName(){
        return scizorHO.nameOfSet();
    }
     
    public String scizorHODescription(){
        return scizorHO.description();
    }
}
