/*
 * Jonathan Nushi
 */

 class Greninja implements Pokemon{
    public String name(){
        return "Greninja";
    }

    public String nameOfSet(){
        return "Greninja";
    }

    public String set(){
       return "https://pokepast.es/4bd664ce7538949d";
    }

    public String description(){
        return "Greninja is a fast and hard hitting Pokemon thanks to its high offensive stats and Protean ability, which changes Greninja’s typing to that of whatever attack it is using right before it attacks, giving whatever attack Greninja uses a 1.5x boost in power. This effect only activates once every time Greninja is switched, and it reverts to its original typing once switched out, hence why most Greninjas tend to run Choice Specs, so that it may capitalize on this boost in power.";
    }
 }