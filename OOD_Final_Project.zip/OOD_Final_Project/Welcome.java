/*
 * Jonathan Nushi
 */
import java.util.*;

 public class Welcome{
    public static void main(String[] args){
        System.out.println("Hi there! Before we begin, have you ever played Pokemon competitive singles? Please enter yes or no.");
        Scanner input = new Scanner(System.in);
        String playedResponse = input.nextLine(); 

        if ((playedResponse.equalsIgnoreCase("Yes")) == true){
            System.out.println("Perfect! Looks like I won't have to explain the basic rules then.");
        } else if ((playedResponse.equalsIgnoreCase("No")) == true){
            System.out.println("Understood. Competetive Pokemon singles is a 1v1 format where each trainer brings a team of 6 Pokemon, similar to what players come across in a standard playthrough of the single-player game."
             + " The objective, of course, is to knock out all of your opponent's Pokemon before they knock out yours." 
             + " Single battles most commonly take place in a fan developed browser-based website appropriately named 'Pokemon Showdown', where players are allowed to quickly create and customize a team of whatever Pokemon they want, and play games in multiple different formats against other players around the world."
             + " For this program, we will be focusing on generation 9 OverUsed, or OU for short. Singles is a usage based format where the most commonly used, in other words the strongest, Pokemon are placed in higher tiers."
             + " Pokemon in higher tiers cannot be used in lower tiers, but any Pokemon in a lower tier, such as the second highest format UnderUsed (UU), can be used in any tier above it."
             + " OU is the most popular tier and is the tier that I play, so this program will be aimed at helping the user (That's you!) build their very own OU team."
             + "For reference, here is a link to a replay of a battle that I've played: https://replay.pokemonshowdown.com/gen9ou-1860498377 (I'm the guy who won).");
        } else {
            input.close();
            throw new IllegalArgumentException("Please reply yes or no to the previous question.");
        }
        int i = 0;
        while(i < 2){
            System.out.println();
            i += 1;
        }
        System.out.println("Team building in Pokemon can be a difficult task, and is often what scares away new players from trying to play it competitively."
        + " It is very easy to find a team that someone else made online and play with that, but doing so as a new player may make it difficult to understand what the role of each Pokemon is, as well as understanding what the thought process is behind creating one's own team."
        + " So, this program's aim is to 1: Guide the user through the thought process and logic of building teams of different archetypes" 
        + " 2: Provide the user with common example sets for a handful of the most popular Pokemon in the tier"
        + " 3: Help the user understand which Pokemon synergize with one another"
        + " And lastly, 4: Have fun with the game!"
        + " For anymore clarifications on how the program operates, please refer to the write-up attached in the project folder.");

        int j = 0;
        while(j < 2){
            System.out.println();
            j += 1;
        }

        System.out.println("Now, for the first step you must determine what type of team you would like to build. There are a vast number of playstyles and"
        + " team archetypes within competitive Pokemon, but we can break down a majority of them into three basic categories: Balance, Hyper Offense, and Stall."
        + " In other words, Balance is what you expect; a team composed of a healthy mix of both offensive threats and reliable defensive Pokemon, typically half and half of each."
        + " Hyper Offense (Or HO) is a risky all-out playstyle full of offensive Pokemon and supportive Pokemon that enable them, focused on immediately pressuring the opponent and making trades and gambles in favor of gaining momentum."
        + " Stall is a much slower and stable playstyle composed of defensive walls that focus on wearing down the opponent's team over time through residual damage and resource management, Stall teams aim to have a defensive answer for just about any offensive threat your opponent may have."
        + " These different playstyles even have different subcategories within them that are slight variations of these basic gameplans just described."
        + " Within this project there are Hyper Offense Sun, Hyper Offense Psychic Terrain, and Stall + Offensive Threat; although of course there are plenty more strategies out there than just these ones."
        + " The two Hyper Offense teams are simply Hyper Offense teams centered around Sun and Psychic Terrain respectively, in which one main Pokemon sets up Sun/Psychic Terrain and the rest of team consists of Pokemon that have abilities or attacks that take advantage of these conditions."
        + " Stall + Offensive Threat is similar to most other Stall teams, but it incorperates one very fast offensive Pokemon in the team in order to keep other specific offensive Pokemon in check. This threat often enters and exits the field frequently, and can allow you to safely switch in your other Pokemon by threatening out your opponent's Pokemon.");
        
        int k = 0;
        while(k < 2){
            System.out.println();
            k += 1;
        }


        ArrayList<String> teamSlots = new ArrayList<String>();
        ArrayList<String> teamSets = new ArrayList<String>();
        int length = teamSlots.size();
        System.out.println("Before we do anything, what would like to name your team?");
        String teamNameResponse = input.nextLine();
        SingletonTeam newTeam = SingletonTeam.createTeam(teamNameResponse);
        String teamName = newTeam.getName();
        System.out.println("With all that being said, which type of team would you like to start building? Balance, Hyper Offense, or Stall?");
        String playStyleResponse = input.nextLine(); 

        if ((playStyleResponse.equalsIgnoreCase("Balance")) == true){
            System.out.println("Ok, Balance it is!");
            TeamState team = new Balance();
            TeamType ba = new TeamType(team);
            PokemonFacadeBA baf = new PokemonFacadeBA();
            if (ba.getState() == "balance"){
                baf.populateBANames();
                System.out.println("Team Type is: " + ba.getTeam());
            }
            
            while (length < 6){
                System.out.println("Here are all the Pokemon sets within the Balance archetype. Please type in a displayed Pokemon's name to view a set and its description.");
                System.out.println(baf.displayBANames());
                System.out.println("Here is your team so far: " + teamName + ":" + teamSlots);
                String pokemonSelector = input.nextLine();
                if ((pokemonSelector.equalsIgnoreCase("Gholdengo set 1")) == true){
                    System.out.println(baf.gholdengoBA1Description());
                    System.out.println(baf.gholdengoBA1Set());
                    String pokemonName = baf.gholdengoBA1Name();
                    String pokemonSet = baf.gholdengoBA1Set();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                        
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Gholdengo set 2")) == true){
                    System.out.println(baf.gholdengoBA2Description());
                    System.out.println(baf.gholdengoBA2Set());
                    String pokemonName = baf.gholdengoBA2Name();
                    String pokemonSet = baf.gholdengoBA2Set();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                        
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Gholdengo set 3")) == true){
                    System.out.println(baf.gholdengoBA3Description());
                    System.out.println(baf.gholdengoBA3Set());
                    String pokemonName = baf.gholdengoBA3Name();
                    String pokemonSet = baf.gholdengoBA3Set();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                        
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Skeledirge")) == true){
                    System.out.println(baf.skeledirgeBADescription());
                    System.out.println(baf.skeledirgeBASet());
                    String pokemonName = baf.skeledirgeBAName();
                    String pokemonSet = baf.skeledirgeBASet();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                        
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Rotom Wash Set 1")) == true){
                    System.out.println(baf.rotomWashBA1Description());
                    System.out.println(baf.rotomWashBA1Set());
                    String pokemonName = baf.rotomWashBA1Name();
                    String pokemonSet = baf.rotomWashBA1Set();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                        
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Rotom Wash Set 2")) == true){
                    System.out.println(baf.rotomWashBA2Description());
                    System.out.println(baf.rotomWashBA2Set());
                    String pokemonName = baf.rotomWashBA2Name();
                    String pokemonSet = baf.rotomWashBA2Set();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                        
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Great Tusk set 1")) == true){
                    System.out.println(baf.greatTuskBA1Description());
                    System.out.println(baf.greatTuskBA1Set());
                    String pokemonName = baf.greatTuskBA1Name();
                    String pokemonSet = baf.greatTuskBA1Set();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                        
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Great Tusk set 2")) == true){
                    System.out.println(baf.greatTuskBA2Description());
                    System.out.println(baf.greatTuskBA2Set());
                    String pokemonName = baf.greatTuskBA2Name();
                    String pokemonSet = baf.greatTuskBA2Set();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                        
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Clodsire")) == true){
                    System.out.println(baf.clodsireBADescription());
                    System.out.println(baf.clodsireBASet());
                    String pokemonName = baf.clodsireBAName();
                    String pokemonSet = baf.clodsireBASet();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                        
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Dragonite")) == true){
                    System.out.println(baf.dragoniteBADescription());
                    System.out.println(baf.dragoniteBASet());
                    String pokemonName = baf.dragoniteBAName();
                    String pokemonSet = baf.dragoniteBASet();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                        
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                }    //else if{}
                length = teamSlots.size();
            }
            System.out.println("Okay! Here is your completed " + team.getState() + " team!" + teamSlots);
            System.out.println("And here are the sets for these Pokemon. Enjoy!" + teamSets);
            System.out.println("Hopefully you found this program helpful! Remember, feel free to edit these sets however you wish, and feel free to create as many teams as you wish, with or without the help of this program."
            + "Building more teams will help you improve your skills both as a team builder and a battler, so please build to your heart's content! Good luck on the ladder!");
            input.close();
        } else if ((playStyleResponse.equalsIgnoreCase("Hyper Offense")) == true){
            System.out.println("Ok, Hyper Offense it is!");
            TeamState team = new HyperOffense();
            TeamType ho = new TeamType(team);
            PokemonFacadeHO hof = new PokemonFacadeHO();
            if (ho.getState() == "hyperOffense"){
                hof.populateHONames();
                System.out.println("Team Type is: " + ho.getTeam());
            }
            
            while (length < 6){
                System.out.println("Here are all the Pokemon sets within the Hyper Offense archetype. Please type in a displayed Pokemon's name to view a set and its description.");
                System.out.println(hof.displayHONames());
                System.out.println("And here is your team so far: " + teamName + ":" + teamSlots);
                String pokemonSelector = input.nextLine();
                if ((pokemonSelector.equalsIgnoreCase("Gholdengo")) == true){
                    System.out.println(hof.gholdengoHODescription());
                    System.out.println(hof.gholdengoHOSet());
                    String pokemonName = hof.gholdengoHOName();
                    String pokemonSet = hof.gholdengoHOSet();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                        
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Torkoal")) == true){
                    System.out.println(hof.torkoalDescription());
                    System.out.println(hof.torkoalSet());
                    String pokemonName = hof.torkoalName();
                    String pokemonSet = hof.torkoalSet();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                            TeamState switched = team.changeState1();
                            ho = new TeamType(switched);
                            System.out.println("Team type is now: " + ho.getTeam());
                            hof.populateHOSunNames(); 
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                       
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Walking Wake")) == true && ho.getState() == "sun"){
                    System.out.println(hof.walkingWakeDescription());
                    System.out.println(hof.walkingWakeSet());
                    String pokemonName = hof.walkingWakeName();
                    String pokemonSet = hof.walkingWakeSet();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                       
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Indeedee")) == true){
                    System.out.println(hof.indeedeeDescription());
                    System.out.println(hof.indeedeeSet());
                    String pokemonName = hof.indeedeeName();
                    String pokemonSet = hof.indeedeeSet();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                            TeamState switched = team.changeState2();
                            ho = new TeamType(switched);
                            System.out.println("Team type is now: " + ho.getTeam());
                            hof.populateHOPTNames(); 
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                       
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Polteageist")) == true && ho.getState() == "PT"){
                    System.out.println(hof.polteageistDescription());
                    System.out.println(hof.polteageistSet());
                    String pokemonName = hof.polteageistName();
                    String pokemonSet = hof.polteageistSet();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                       
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Armarouge")) == true && ho.getState() == "PT"){
                    System.out.println(hof.armarougeDescription());
                    System.out.println(hof.armarougeSet());
                    String pokemonName = hof.armarougeName();
                    String pokemonSet = hof.armarougeSet();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                       
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Roaring Moon")) == true && ho.getState() == "sun"){
                    System.out.println(hof.roaringMoonDescription());
                    System.out.println(hof.roaringMoonSet());
                    String pokemonName = hof.roaringMoonName();
                    String pokemonSet = hof.roaringMoonSet();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                       
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Greninja"))){
                    System.out.println(hof.greninjaDescription());
                    System.out.println(hof.greninjaSet());
                    String pokemonName = hof.greninjaName();
                    String pokemonSet = hof.greninjaSet();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                       
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Cinderace"))){
                    System.out.println(hof.cinderaceDescription());
                    System.out.println(hof.cinderaceSet());
                    String pokemonName = hof.cinderaceName();
                    String pokemonSet = hof.cinderaceSet();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                       
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Kingambit"))){
                    System.out.println(hof.kingambitHODescription());
                    System.out.println(hof.kingambitHOSet());
                    String pokemonName = hof.kingambitHOName();
                    String pokemonSet = hof.kingambitHOSet();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                       
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                } else if ((pokemonSelector.equalsIgnoreCase("Scizor"))){
                    System.out.println(hof.scizorHODescription());
                    System.out.println(hof.scizorHOSet());
                    String pokemonName = hof.scizorHOName();
                    String pokemonSet = hof.scizorHOSet();
                    System.out.println("Would you like to add this Pokemon to your team?");
                    String yesOrNo = input.nextLine();
                    if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                        if (!teamSlots.contains(pokemonName)){
                            teamSlots.add(pokemonName);
                        } else {
                            System.out.println("This Pokemon is already on your team.");
                        }
                        if (!teamSets.contains(pokemonSet)){
                            teamSets.add(pokemonSet);
                        }                       
                    } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                        System.out.println("Ok, we'll keep looking then.");
                    }
                }  //else if
                length = teamSlots.size();
            }
            System.out.println("Okay! Here is your completed " + team.getState() + " team!" + teamSlots);
            System.out.println("And here are the sets for these Pokemon. Enjoy!" + teamSets);
            System.out.println("Hopefully you found this program helpful! Remember, feel free to edit these sets however you wish, and feel free to create as many teams as you wish, with or without the help of this program."
            + "Building more teams will help you improve your skills both as a team builder and a battler, so please build to your heart's content! Good luck on the ladder!");
            input.close();
        } else if ((playStyleResponse.equalsIgnoreCase("Stall")) == true){
            System.out.println("Would you like a standard Stall team, or a StallThreat team? Please type your response exactly as how the team names are stated.");
            String subArchetypeResponse = input.nextLine();
            if ((subArchetypeResponse.equalsIgnoreCase("Stall")) == true){
                System.out.println("Here are all the Pokemon sets within the Stall archetype.");
                TeamState team = new Stall();
                TeamType st = new TeamType(team);
                PokemonFacadeST stf = new PokemonFacadeST();
                System.out.println("Ok Stall it is!");
                if (st.getState() == "stall"){
                    stf.populateSTNames();
                    System.out.println("Team Type is: " + st.getTeam());
                }
                while (length < 6){
                    System.out.println("Here are all the Pokemon sets within the Stall archetype. Please type in a displayed Pokemon's name to view a set and its description.");
                    System.out.println(stf.displaySTNames());
                    System.out.println("And here is your team so far: "  + teamName + ":" + teamSlots);
                    String pokemonSelector = input.nextLine();
                    if ((pokemonSelector.equalsIgnoreCase("Gholdengo")) == true){
                        System.out.println(stf.gholdengoSTDescription());
                        System.out.println(stf.gholdengoSTSet());
                        String pokemonName = stf.gholdengoSTName();
                        String pokemonSet = stf.gholdengoSTSet();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                        
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    } else if ((pokemonSelector.equalsIgnoreCase("Clodsire"))){
                        System.out.println(stf.clodsireSTDescription());
                        System.out.println(stf.clodsireSTSet());
                        String pokemonName = stf.clodsireSTName();
                        String pokemonSet = stf.clodsireSTSet();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                       
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    } else if ((pokemonSelector.equalsIgnoreCase("Dondozo"))){
                        System.out.println(stf.dondozoSTDescription());
                        System.out.println(stf.dondozoSTSet());
                        String pokemonName = stf.dondozoSTName();
                        String pokemonSet = stf.dondozoSTSet();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                       
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    } else if ((pokemonSelector.equalsIgnoreCase("Garganacl"))){
                        System.out.println(stf.garganaclSTDescription());
                        System.out.println(stf.garganaclSTSet());
                        String pokemonName = stf.garganaclSTName();
                        String pokemonSet = stf.garganaclSTSet();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                       
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    } else if ((pokemonSelector.equalsIgnoreCase("Talonflame"))){
                        System.out.println(stf.talonflameDescription());
                        System.out.println(stf.talonflameSet());
                        String pokemonName = stf.talonflameName();
                        String pokemonSet = stf.talonflameSet();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                       
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    } else if ((pokemonSelector.equalsIgnoreCase("Ting Lu"))){
                        System.out.println(stf.tingLuSTDescription());
                        System.out.println(stf.tingLuSTSet());
                        String pokemonName = stf.tingLuSTName();
                        String pokemonSet = stf.tingLuSTSet();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                       
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    } else if ((pokemonSelector.equalsIgnoreCase("Alomomola"))){
                        System.out.println(stf.alomomolaDescription());
                        System.out.println(stf.alomomolaSet());
                        String pokemonName = stf.alomomolaName();
                        String pokemonSet = stf.alomomolaSet();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                       
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    }   //else if
                    length = teamSlots.size();
                }
                System.out.println("Okay! Here is your completed " + team.getState() + " team!" + teamSlots);
                System.out.println("And here are the sets for these Pokemon. Enjoy!" + teamSets);
                System.out.println("Hopefully you found this program helpful! Remember, feel free to edit these sets however you wish, and feel free to create as many teams as you wish, with or without the help of this program."
                + "Building more teams will help you improve your skills both as a team builder and a battler, so please build to your heart's content! Good luck on the ladder!");
                input.close(); 
            } else if ((subArchetypeResponse.equalsIgnoreCase("StallThreat")) == true){
                TeamState team = new StallThreat();
                TeamType st = new TeamType(team);
                PokemonFacadeST stf = new PokemonFacadeST();
                System.out.println("Ok StallThreat it is!");
                if (st.getState() == "stallThreat"){
                    stf.populateSTNames();
                    stf.populateSTThreatNames();
                    System.out.println("Team Type is: " + st.getTeam());
                }
                while (length < 6){
                    System.out.println("Here are all the Pokemon sets within the StallThreat archetype. Please type in a displayed Pokemon's name to view a set and its description.");
                    System.out.println(stf.displaySTNames());
                    System.out.println("And here is your team so far: " + teamName + ":" + teamSlots);
                    String pokemonSelector = input.nextLine();
                    if ((pokemonSelector.equalsIgnoreCase("Gholdengo")) == true){
                        System.out.println(stf.gholdengoSTDescription());
                        System.out.println(stf.gholdengoSTSet());
                        String pokemonName = stf.gholdengoSTName();
                        String pokemonSet = stf.gholdengoSTSet();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                        
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    } else if ((pokemonSelector.equalsIgnoreCase("Clodsire"))){
                        System.out.println(stf.clodsireSTDescription());
                        System.out.println(stf.clodsireSTSet());
                        String pokemonName = stf.clodsireSTName();
                        String pokemonSet = stf.clodsireSTSet();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                       
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    } else if ((pokemonSelector.equalsIgnoreCase("Dondozo"))){
                        System.out.println(stf.dondozoSTDescription());
                        System.out.println(stf.dondozoSTSet());
                        String pokemonName = stf.dondozoSTName();
                        String pokemonSet = stf.dondozoSTSet();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                       
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    } else if ((pokemonSelector.equalsIgnoreCase("Garganacl"))){
                        System.out.println(stf.garganaclSTDescription());
                        System.out.println(stf.garganaclSTSet());
                        String pokemonName = stf.garganaclSTName();
                        String pokemonSet = stf.garganaclSTSet();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                       
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    } else if ((pokemonSelector.equalsIgnoreCase("Talonflame"))){
                        System.out.println(stf.talonflameDescription());
                        System.out.println(stf.talonflameSet());
                        String pokemonName = stf.talonflameName();
                        String pokemonSet = stf.talonflameSet();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                       
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    } else if ((pokemonSelector.equalsIgnoreCase("Ting Lu"))){
                        System.out.println(stf.tingLuSTDescription());
                        System.out.println(stf.tingLuSTSet());
                        String pokemonName = stf.tingLuSTName();
                        String pokemonSet = stf.tingLuSTSet();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                       
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    } else if ((pokemonSelector.equalsIgnoreCase("Alomomola"))){
                        System.out.println(stf.alomomolaDescription());
                        System.out.println(stf.alomomolaSet());
                        String pokemonName = stf.alomomolaName();
                        String pokemonSet = stf.alomomolaSet();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                       
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    } else if ((pokemonSelector.equalsIgnoreCase("Dragapult set 1"))){
                        System.out.println(stf.dragapultST1Description());
                        System.out.println(stf.dragapultST1Set());
                        String pokemonName = stf.dragapultST1Name();
                        String pokemonSet = stf.dragapultST1Set();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                       
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    } else if ((pokemonSelector.equalsIgnoreCase("Dragapult set 2"))){
                        System.out.println(stf.dragapultST2Description());
                        System.out.println(stf.dragapultST2Set());
                        String pokemonName = stf.dragapultST2Name();
                        String pokemonSet = stf.dragapultST2Set();
                        System.out.println("Would you like to add this Pokemon to your team?");
                        String yesOrNo = input.nextLine();
                        if ((yesOrNo.equalsIgnoreCase("Yes")) == true){
                            if (!teamSlots.contains(pokemonName)){
                                teamSlots.add(pokemonName);
                            } else {
                                System.out.println("This Pokemon is already on your team.");
                            }
                            if (!teamSets.contains(pokemonSet)){
                                teamSets.add(pokemonSet);
                            }                       
                        } else if ((yesOrNo.equalsIgnoreCase("No")) == true){
                            System.out.println("Ok, we'll keep looking then.");
                        }
                    }   //else if
                    length = teamSlots.size();
                }
                System.out.println("Okay! Here is your completed " + team.getState() + " team!" + teamSlots);
                System.out.println("And here are the sets for these Pokemon. Enjoy!" + teamSets);
                System.out.println("Hopefully you found this program helpful! Remember, feel free to edit these sets however you wish, and feel free to create as many teams as you wish, with or without the help of this program."
                + "Building more teams will help you improve your skills both as a team builder and a battler, so please build to your heart's content! Good luck on the ladder!");
                input.close();
            } 
        } else {
            input.close();
            throw new IllegalArgumentException("Please reply with Balance, Hyper Offense, or Stall to the previous question.");
        }
    }
}