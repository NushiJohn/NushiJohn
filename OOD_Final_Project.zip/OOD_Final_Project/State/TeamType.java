/*
 * Jonathan Nushi
 */

 public class TeamType
{
    private TeamState state;
	
    public TeamType(TeamState state) 
	{
        this.state = state;
    }

	public String getTeam()
	{
		return state.getTeam();
	}

    public String getState()
	{
        return state.getState();
    }
}