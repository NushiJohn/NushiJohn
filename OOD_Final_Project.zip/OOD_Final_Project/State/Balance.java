/*
 * Jonathan Nushi
 */
public class Balance implements TeamState 
{
    private String team = "Balance Team";
    
    public String getState() 
	{
        return "balance";
    }

	public String getTeam()
	{
		return team;
	}

	public TeamState changeState1() 
	{
        return new Balance();
    }

    public TeamState changeState2() 
	{
        return new Balance();
    }
}
