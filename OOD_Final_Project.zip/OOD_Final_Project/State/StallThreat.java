/*
 * Jonathan Nushi
 */
public class StallThreat implements TeamState 
{
    private String team = "Stall + Threat Team";
    
    public String getState() 
	{
        return "stallThreat";
    }

	public String getTeam()
	{
		return team;
	}
    public TeamState changeState1() 
	{
        return new StallThreat();
    }

    public TeamState changeState2() 
	{
        return new StallThreat();
    }
}