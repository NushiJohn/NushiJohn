/*
 * Jonathan Nushi
 */
public class HOSun implements TeamState 
{
    private String team = "Hyper Offense Sun Team";
    
    public String getState() 
	{
        return "sun";
    }

	public String getTeam()
	{
		return team;
	}

	public TeamState changeState1() 
	{
        return new HOSun();
    }

    public TeamState changeState2() 
	{
        return new HOSun();
    }
}