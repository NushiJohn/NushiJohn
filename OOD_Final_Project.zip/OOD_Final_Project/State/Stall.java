/*
 * Jonathan Nushi
 */
public class Stall implements TeamState 
{
    private String team = "Stall Team";
    
    public String getState() 
	{
        return "stall";
    }

	public String getTeam()
	{
		return team;
	}

    public TeamState changeState1() 
	{
        return new StallThreat();
    }

    public TeamState changeState2() 
	{
        return new StallThreat();
    }
}