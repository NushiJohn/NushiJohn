/*
 * Jonathan Nushi
 */
public class HyperOffense implements TeamState 
{
    private String team = "Hyper Offense Team";
    
    public String getState() 
	{
        return "hyperOffense";
    }

	public String getTeam()
	{
		return team;
	}

    public TeamState changeState1() 
	{
        return new HOSun();
    }

    public TeamState changeState2() 
	{
        return new HOPsychicT();
    }
}