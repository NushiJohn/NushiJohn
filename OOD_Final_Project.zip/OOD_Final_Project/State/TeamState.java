/*
 * Jonathan Nushi
 */

 public interface TeamState 
{
    String getState();
	String getTeam();
    TeamState changeState1();
    TeamState changeState2();
}
