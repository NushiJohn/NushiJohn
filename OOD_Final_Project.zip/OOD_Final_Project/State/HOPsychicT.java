/*
 * Jonathan Nushi
 */
public class HOPsychicT implements TeamState 
{
    private String team = "Hyper Offense Pychic Terrain Team";
    
    public String getState() 
	{
        return "PT";
    }

	public String getTeam()
	{
		return team;
	}
	public TeamState changeState1() 
	{
        return new HOPsychicT();
    }

    public TeamState changeState2() 
	{
        return new HOPsychicT();
    }
}