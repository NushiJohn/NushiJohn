/*
 * Jonathan Nushi
 */

 public class SingletonTeam{
    private String name;

    private static SingletonTeam singletonTeam;

    protected SingletonTeam(String n)
	{
		name = n;
	}

    
	public static SingletonTeam createTeam(String n)
	{
		if (singletonTeam == null)
		{
			singletonTeam = new SingletonTeam(n);
		}

		else
		{
			System.out.println("You have already created a team.");
		}
	
		return singletonTeam;
	}

	public static void removePokemonFromTeam()
	{
		singletonTeam = null;
    }

    public String getName()
	{
		return name;
	}
 }