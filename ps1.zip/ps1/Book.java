/*
 * creates a Book class
 *
 * Jonathan Nushi
 */

import java.util.Set;
import java.util.LinkedHashSet;


public class Book implements Comparable<Book>
{
    public static int counter = 0;  // static item for counter for books
    public static LinkedHashSet<String> bannedBooksSet = new LinkedHashSet<String>();  //set of banned books
    private String title;  //instance variables
    private int pages;
    private String color;
    private int bookNumber;


    //method for returning number of books
    public static int numberOfBooks(){
        return counter;
    }



    //method for returing set of banned books
    public static LinkedHashSet<String> bannedBooks(){
        return bannedBooksSet;
    }


    //method for capitalizing and adding banned book titles
    public static void addBannedTitle(String title){
        String result = title.substring(0, 1).toUpperCase() + title.substring(1);
        bannedBooksSet.add(result);
    }
    

    //no argument constructor
    public Book(){
        title = "Designing with Objects";
        pages = 512;
        color = "burgundy";
        counter++;
    }


    //argument constructor
    public Book(String t, int p, String c){
        title = t;
        pages = p;
        color = c;
        counter++;
    }
    //increment book counter every time a new book is created


    //setters
    public void setTitle (String t){
    setTitle(t);
    }


    public void setPages (int p){
    if (pages < 0){
    setPages(p);
    }
    }


    public void setColor (String c){
    setColor(c);
    }


    //getters
    public String getTitle(){
    return title;
    }

    public int getPages(){
    return pages;
    }

    public String getColor(){
    return color;
    }

    public int getNumber(){
    return bookNumber;
    }


    //same pages instance method
    public boolean hasSamePages(Book b){
        return this.pages == b.pages;
    }


    //overriden methods
    public String toString(){
        return "title\t" + title + "pages\t" + pages + "color\t" + color;
    }


    public boolean equal(Object o){
        if (o instanceof Book){
            Book b = (Book) o;
            return title == b.title && pages == b.pages;
        }
        return false;
    }


    public int hashCode(){
        return Integer.hashCode(pages) + color.hashCode();
    }


    //compareTo
    public int compareTo (Book b){
        if (pages < b.pages) return -1;
        if (pages > b.pages) return 1;
        return 0;
    }
}
