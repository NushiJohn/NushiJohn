/*
 * creates a fiction subclass for books
 *
 * Jonathan Nushi
 */

public class Fiction extends Book
{
    private Genre genre;    //instance variable


    public Fiction(){       //no argument constructor
        setTitle("Murder on the Orient Express");
        setPages(212);
        setColor("white");
        this.genre = Genre.MYSTERY;
    }


    public Fiction(String title, int pages, String color, Genre genre){     //argument constructor
        setTitle(title);
        setPages(pages);
        setColor(color);
        this.genre = genre;
    }

    public final void setGenre(Genre genre){        //setter for genre
        this.genre = genre;
    }

    public Genre getGenre(){        //getter for genre
        return this.genre;
    }


    public boolean isSameGenre(Fiction f){      //compare two genres
        return this.genre == f.genre;
    }

    public int randomRating(){      //randomRating
        int rating;
        if (this.genre == Genre.MYSTERY){
            rating = (int) ((Math.random() * (5-3)) + 3);
        } else if (this.genre == Genre.FANTASY){
            rating = (int) ((Math.random() * (4-2)) + 2);
        } else {rating = (int) ((Math.random() * (5-1)) + 1);
        }
        return rating;
    }


    public String toString(){       //addition of genre to toString
        return super.toString() + "\ngenre\t" + this.genre;
    }
}
