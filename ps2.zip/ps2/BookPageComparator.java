/*
 * creates a comparator for sorting books by pages 
 *
 * Jonathan Nushi
 */

import java.util.Comparator;

public class BookPageComparator implements Comparator<Book>
{
    public int compare(Book b1, Book b2){
        if (b1.getPages() < b2.getPages()) return -1;
        if (b1.getPages() > b2.getPages()) return 1;
        return 0;
    }
}	
