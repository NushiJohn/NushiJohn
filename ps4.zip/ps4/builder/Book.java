/*
 * Jonathan Nushi
 */

public class Book
{
    private String title;  //instance variables
    private int pages;
    private String author;
    private int year;


    public static class Builder{    //Builder class
        private String title;
        private int pages;
        private String author;
        private int year;

        public Builder (String t, int p)
		{
			title = t;
			pages = p;
		}

		public Builder author (String a)
		{
			author = a;
			return this;
		}

        public Builder year (int y)
		{
			year = y;
			return this;
		}	
        
        public Book build(){
            return new Book(this);
        }
}

private Book(Builder b)
{
    title = b.title;
    pages = b.pages;
    author = b.author;
    year = b.year;
}

    //overriden methods
    public String toString(){
        return "title\t" + this.title + "\npages\t" + this.pages + "\nauthor\t" + this.author + "\nyear\t" + this.year;
        }
}
