/* 
 * Jonathan Nushi
 */

public class UnknownGenreException extends Exception 
{
    public UnknownGenreException(String message) {
        // Argument Constructor
        super(message);
    }
    public UnknownGenreException() {
        // No Argument Constructor
        super();
    }
}
