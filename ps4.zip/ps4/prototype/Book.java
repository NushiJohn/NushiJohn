/*
 * Jonathan Nushi
 */

public class Book implements Cloneable 
{
    private String title;  //instance variables
    private String author;
    private int year;

    private Book (String g) throws UnknownGenreException 
	{
 		if (g.equals("fantasy")) 
		{
			title = "Harry Potter and the Philosopher's Stone";
            author = "Rowling";
            year = 1997;
       	} 
		else if (g.equals("textbook"))
		{
			title = "Designing with Objects";
            author = "Kak";
            year = 2014;	
       	}
           else if (g.equals("humor"))
           {
               title = "Inmitable Jeeves";
               author = "Wodehouse";
               year = 1923;	
              }
		else
		{
			throw new UnknownGenreException("The book club is not reading " + g + " books at the moment");
		} 
    }

    public void setTitle(String t){
        this.title = t;
    }

    public void setYear(int y){
        this.year = y;
    }

    public static Book makeBook(String g) throws UnknownGenreException 
	{
        return new Book(g);
    }

    public Object clone() throws CloneNotSupportedException 
	{
        return super.clone();
    }

    public boolean equals(Object o)
	{
		if (o instanceof Book)
		{
			Book b = (Book) o;
			return title.equals(b.title) &&  
				year == b.year && author.equals(b.author);
		}
		return false;
	}

    public String toString() 
	{
        return title + " " + author + " " + year;
    }
}
