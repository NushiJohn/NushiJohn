/*
 * Jonathan Nushi
 */

public class BookDuplicator 
{
	private Book fantasyPrototype;
	private Book textbookPrototype;
    private Book humorPrototype;

	private static BookDuplicator bd;


    private BookDuplicator() 
	{
		try
		{
			fantasyPrototype = Book.makeBook("fantasy");
			textbookPrototype = Book.makeBook("textbook");
            humorPrototype = Book.makeBook("humor");
		}

		catch (UnknownGenreException e)
		{
			System.out.println(e.getMessage());
		}
	}

    public static BookDuplicator makeBookDuplicator()
	{
		if (bd == null)
		{
			bd = new BookDuplicator();
		}
		return bd;
	}

    public Book duplicateBook(String g)
	{
		Book b = null;

        try
        {
            if (g.equals("fantasy"))
            {
                b = (Book) fantasyPrototype.clone();
            }
            else if (g.equals("textbook"))
            {
                b = (Book) textbookPrototype.clone();
            }
            else if (g.equals("humor"))
            {
                b = (Book) humorPrototype.clone();
            }
        }
        catch (CloneNotSupportedException e)
        {
            System.out.println(e.getMessage());
        }
        return b;
    }
}
