/*
 *Jonathan Nushi
 */

public class Print extends Book
{
    private static String binding;

    public Print(String title, String binding){
        super(title, binding);
    }
    public Print(String title, String cover, String binding){
        super(title, cover, binding);
    }

    public String toString(){
        String s = this.getTitle() + ", " + this.getClass().getName();
        if (this.getCover() != null){
            s = s + ", " + this.getCover();
        }
        return s;
    }
}


