/*
 *Jonathan Nushi
 */

public abstract class Book 
{
    private String title;
    private String cover;

    protected Book(String title){
        this.title = title;
    }

    protected Book(String title, String cover){
        this.title = title;
        this.cover = cover;
    }

    public String getTitle(){
        return this.title;
    }

    public String getCover(){
        return this.cover;
    }


    public String toString(){
        String s = this.getTitle() + ", " + this.getClass().getName();
        if (this.getCover() != null){
            s = s + ", " + this.getCover();
        }
        return s;
    }
}
