/*
 *Jonathan Nushi
 */

public class FactoryMaker
{
    private static FactoryMaker store;
    private FactoryMaker(){}

    public static FactoryMaker makeFactoryStore(){
        if (store == null){
            store = new FactoryMaker();
        }
        return store;
    }

    public Print deliverPrint(String title){
        return new Print(title);
    }

    public Print deliverPrint(String title, String cover){
        return new Print(title, cover);
    }

    public Print deliverDigital(String title){
        return new Print(title);
    }

    public Print deliverDigital(String title, String cover){
        return new Print(title, cover);
    }
}
