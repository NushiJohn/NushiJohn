/*
 *Jonathan Nushi
 */

public class Digital extends Book
{
    public Digital(String title) {
        super(title);
    }
    public Digital(String title, String cover){
        super(title, cover);
    }
}


