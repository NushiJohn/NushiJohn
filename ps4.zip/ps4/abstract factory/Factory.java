/*
 *Jonathan Nushi
 */

public abstract class Factory
{
    protected FactoryMaker store;

    public Factory(){
        store = FactoryMaker.makeFactoryStore();
    }

    public abstract Book deliverPrint(String title);

    public abstract Book deliverDigital(String title);
}


