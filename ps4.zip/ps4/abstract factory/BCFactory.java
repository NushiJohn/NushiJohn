/*
 * Jonathan Nushi
 */

import java.util.List;
import java.util.ArrayList;

public class BCFactory extends Factory
{
    private ArrayList<String> list_of_covers = 
    new ArrayList<String>(Array.asList("Baldwin the Eagle", "BC Eagles", "Heights"));

    private String getRandom(){
        return list_of_covers.get((int) (Math.random() * list_of_covers.size()));
    }

    public Book deliverPrint(String title){
        return store.deliverPrint(title, getRandom());
    }

    public Book deliverDigital(String title){
        return store.deliverDigital(title, getRandom());
    }
}
