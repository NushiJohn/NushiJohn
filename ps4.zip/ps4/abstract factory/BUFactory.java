/*
 *Jonathan Nushi
 */

public class BUFactory extends Factory
{
    public Book deliverPrint(String title){
        return store.deliverPrint(title);
    }

    public Book deliverDigital(String title){
        return store.deilverDigital(title);
    }
}


