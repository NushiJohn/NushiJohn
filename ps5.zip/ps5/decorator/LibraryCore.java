/*
 * Jonathan Nushi
 */

public class LibraryCore implements Library
{
    public void getLibraryItem() 
	{
        System.out.println("As a Massachusetts resident, you may get a Boston Public Library card.");
    }
}


