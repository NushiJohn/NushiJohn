/*
 * Jonathan Nushi
 */

public interface Library 
{
    void getLibraryItem();
}


