/* 
 * Jonathan Nushi
 */

import java.util.HashMap;

public class BookFactory
{
    private static final HashMap<String, Book> books = new HashMap<>();

	public static Book makeBook(String type)
	{
		Book b = null;

		if (books.get(type) == null)
		{
			if (type.equals("hardback"))
         		b = new Book();
			else if (type.equals("unbound"))
				b = new Book();
            else if (type.equals("paperback"))
				b = new Book();
         	books.put(type, b);
      	}

      	return books.get(type);
   	}
}
