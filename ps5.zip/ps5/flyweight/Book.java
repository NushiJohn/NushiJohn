/*
 * Jonathan Nushi
 */

public class Book
{
    private String title;

    public Book(){
        title = setTitle();
    }

    public final void setTitle (String t){
        this.title = t;
        }

    public String getTitle(){
        return title;
    }

    public String toString(){
    return getTitle();
}
}

