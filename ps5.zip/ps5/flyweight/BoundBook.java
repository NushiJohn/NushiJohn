/*
 * Jonathan Nushi
 */
import java.util.List;
import java.util.ArrayList;

public class BoundBook 
{
	private Book book;
	private List<String> bindings;

	public BoundBook(Book b, String a)
	{
		book = b;
		bindings = new ArrayList<>();
		addBinding(a);
	}

	public void addBinding(String a)
	{
		bindings.add(a);
	}

	public String toString()
	{
		return book + ": " + bindings;
	}
}

