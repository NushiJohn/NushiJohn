/*
 * Jonathan Nushi
 */

public class LibraryFacade{
    private Library centralLibrary;
    private Library mainLibrary;
    private Library oNeillLibrary;
    private Library valenteLibrary;

    public LibraryFacade(){
        centralLibrary = new CentralLibrary();
        mainLibrary = new MainLibrary();
        oNeillLibrary = new ONeillLibrary();
        valenteLibrary = new ValenteLibrary();
    }

    public String getCentralHours(){
        return centralLibrary.pickupHours();
    }

    public String getMainHours(){
        return mainLibrary.pickupHours();
    }

    public String getONeillHours(){
        return oNeillLibrary.pickupHours();
    }

    public String getValenteHours(){
        return valenteLibrary.pickupHours();
    }
}