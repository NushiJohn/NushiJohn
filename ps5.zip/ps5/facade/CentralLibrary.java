/*
 * Jonathan Nushi
 */

public class CentralLibrary implements Library
{
    public String pickupHours(){
    return "MTW 11-5:30 Th 1-7:30";
    }
}
 

