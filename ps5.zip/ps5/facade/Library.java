/*
 * Jonathan Nushi
 */

public interface Library 
{
//     private String hours;

//     public Library(){
//         hours = pickupHours();
//    }

   public String pickupHours();
}


