/*
 * Jonathan Nushi
 */

class MainLibrary implements Library 
{
    public String pickupHours(){
    return "MTW 1-7:30 Fri/Sat 10-4:30";
    }
}
 

