/*
 * Jonathan Nushi
 */

class ONeillLibrary implements Library
{
    public String pickupHours(){
        return "W 1-7:30 Th/Fri 11-5:30";
        }
}
 

