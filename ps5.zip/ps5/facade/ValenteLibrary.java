/*
 * Jonathan Nushi
 */

class ValenteLibrary implements Library
{
    public String pickupHours(){
        return "MTF 11-5:30";
        }
}
 

