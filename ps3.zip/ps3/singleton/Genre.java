/*
 * Jonathan Nushi
 */

 public enum Genre 
 {
     MYSTERY, FANTASY, HUMOR;
 }
