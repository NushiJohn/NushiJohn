/*
 * creates a book class
 *
 * Jonathan Nushi
 */

import java.util.Set;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedHashSet;

public abstract class Book implements Comparable<Book>
{
    private String title;  //instance variables
    protected static List<Book> books = new ArrayList<Book>();
    public static List<Book> booksSignedOutSet = new ArrayList<Book>(); //set of books signed out
    private static Book book1 = null;
    private static Book book2 = null;
    protected Book(String t){
        this.title = t;
    }


  
    public static Book borrowBook(String t) throws BookLimitException{       //borrowBook method
        if (book1 == null) {
            book1 = new Book(t);
            books.add(book1);
            return book1;
        } else if (book2 == null) {
            book2 = new Book(t);
            books.add(book2);
            return book2;
        } else {
			throw new BookLimitException("Maximum borrowing reached!");
        }
    }
    

    public static boolean returnBook(String t){       //returnBook method
        if (book1.getTitle() == t) {
            books.remove(book1);
            book1 = null;
            return true;
        } else if (book2.getTitle() == t) {
            books.remove(book2);
            book2 = null;
            return true;
        } else {
            return false;
        }        if (book1.getTitle() == t) {
            books.remove(book1);
            book1 = null;
            return true;
        } else if (book2.getTitle() == t) {
            books.remove(book2);
            book2 = null;
            return true;
        } else {
            return false;
        }
    }


    public static List<Book> booksSignedOut(){
        return books;
    }


//setter
public final void setTitle (String t){
    this.title = t;
    }


    //getter
    public String getTitle(){
    return title;
    }


    //overriden methods
    public String toString(){
        return "title\t" + title;
    }
}
