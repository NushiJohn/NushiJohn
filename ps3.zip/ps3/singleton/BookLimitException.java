/*
 * Jonathan Nushi
 */

public class BookLimitException extends Exception
{
    public BookLimitException(String s) {
        // Argument Constructor
        super(s);
    }
    public BookLimitException() {
        // No Argument Constructor
        super();
    }
}
