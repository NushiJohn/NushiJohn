/*
 * creates a book class
 *
 * Jonathan Nushi
 */

import java.util.Set;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedHashSet;

public abstract class Book implements Comparable<Book>
{
    private String title;  //instance variables
    private int pages;
    private String color;
    private int bookNumber;
    private int rating;
    public static int counter = 0;  // static item for counter for books
    public static LinkedHashSet<String> bannedBooksSet = new LinkedHashSet<String>();  //set of banned books
    protected static List<Book> books = new ArrayList<Book>();
    public static List<Book> booksSignedOutSet = new ArrayList<Book>(); //set of books signed out
    private static Book book1 = null;
    private static Book book2 = null;
    protected Book(String t){
        this.title = t;
    }


        //method for returning number of books
        public static int numberOfBooks(){
            return counter;
        }
    
    
    
        //method for returing set of banned books
        public static LinkedHashSet<String> bannedBooks(){
            return bannedBooksSet;
        }
    
    
        //method for capitalizing and adding banned book titles
        public static void addBannedTitle(String title){
            String result = title.substring(0, 1).toUpperCase() + title.substring(1);
            bannedBooksSet.add(result);
        }


    //no argument constructor
    public Book(){
        title = "Designing with Objects";
        pages = 512;
        color = "burgundy";
        counter += 1;
        bookNumber = counter;
    }


    //argument constructor
    public Book(String t, int p, String c){
        title = t;
        pages = p;
        color = c;
        counter += 1;
        bookNumber = counter;
    }
    //increment book counter every time a new book is created


    public static Book borrowBook(String t) throws BookLimitException{       //borrowBook method
        if (book1 == null) {
            book1 = new Book(t);
            books.add(book1);
            return book1;
        } else if (book2 == null) {
            book2 = new Book(t);
            books.add(book2);
            return book2;
        } else {
			throw new BookLimitException("Maximum borrowing reached!");
        }
    }
    

    public static boolean returnBook(String t){       //returnBook method
        if (book1.getTitle() == t) {
            books.remove(book1);
            book1 = null;
            return true;
        } else if (book2.getTitle() == t) {
            books.remove(book2);
            book2 = null;
            return true;
        } else {
            return false;
        }        if (book1.getTitle() == t) {
            books.remove(book1);
            book1 = null;
            return true;
        } else if (book2.getTitle() == t) {
            books.remove(book2);
            book2 = null;
            return true;
        } else {
            return false;
        }
    }


    public static List<Book> booksSignedOut(){
        return books;
    }


//setters
public final void setTitle (String t){
    this.title = t;
    }


    public final void setPages (int p){
        this.pages = p;
    }


    public final void setColor (String c){
    this.color = c;
    }

    public final void setRating (int r){
    this.rating = r;
    }


    //getters
    public String getTitle(){
    return title;
    }

    public int getPages(){
    return pages;
    }

    public String getColor(){
    return color;
    }

    public int getNumber(){
    return bookNumber;
    }

    public int getRating(){
        return rating;
    }


    //same pages instance method
    public boolean hasSamePages(Book b){
        return this.pages == b.pages;
    }


    //overriden methods
    public String toString(){
        return "title\t" + title + "\npages\t" + pages + "\ncolor\t" + color + "\nrating\t" + rating;
    }


    public boolean equal(Object o){
        if (o instanceof Book){
            Book b = (Book) o;
            return title == b.title && pages == b.pages;
        }
        return false;
    }


    public int hashCode(){
        return Integer.hashCode(pages) + color.hashCode();
    }


    //compareTo
    public int compareTo (Book b){
        if (pages < b.pages) return -1;
        if (pages > b.pages) return 1;
        return 0;
    }	 

    //abstract methods
    public abstract int randomRating();
}
