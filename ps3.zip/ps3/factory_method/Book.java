/*
 * creates a book class
 *
 * Jonathan Nushi
 */

import java.util.Set;
import java.util.LinkedHashSet;

public abstract class Book implements Comparable<Book>
{
    private String title;  //instance variables
    private int year;


    //argument constructor
    public Book(String t, int y){
        title = t;
        year = y;
    }


    //setters
    public final void setTitle (String t){
    this.title = t;
    }


    public final void setYear (int y){
        this.year = y;
    }


    //getters
    public String getTitle(){
    return title;
    }

    public int getYear(){
    return year;
    }


    //overriden methods
    public String toString(){
        return "title\t" + title + "\nyear\t" + year;
    }


    //compareTo
    public int compareTo (Book b){
        if (year < b.year) return -1;
        if (year > b.year) return 1;
        return 0;
    }	 

    //abstract method
    public abstract String genre();
}
