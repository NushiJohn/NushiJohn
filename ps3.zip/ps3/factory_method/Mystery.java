/*
 * Jonathan Nushi
 */

public class Mystery extends Book
{
    //argument constructor
    public Biography(String title, int year){
        setTitle(title);
        setYear(year);
    }

    super genre(){
        return "memoir";
    }
}
	
	
