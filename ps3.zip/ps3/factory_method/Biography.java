/*
 * Jonathan Nushi
 */

public class Biography extends Book
{
    //argument constructor
    public Biography(String title, int year){
        setTitle(title);
        setYear(year);
    }

    super genre(){
        if (year > 1912 & year < 1939){
            return "golden age";
        }
        else{
            return "hard boiled";
        }
    }
}
