/*
 * Jonathan Nushi
 */

public interface BookMaker
{
    public BookMaker(String title, int year){
        return Book b;
    }
}
