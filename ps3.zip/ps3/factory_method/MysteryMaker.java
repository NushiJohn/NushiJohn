/*
 * Jonathan Nushi
 */

public class MysteryMaker implements BookMaker
{
    public MysteryMaker(String title, int year){
        return Mystery myst;
    }
}
