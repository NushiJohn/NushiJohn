/*
 * Jonathan Nushi
 */

public class BiographyMaker implements BookMaker
{
    public BiographyMaker(String title, int year){
        return Biography bio;
    }
}
