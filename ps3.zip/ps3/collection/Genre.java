/*
 * creates an enumerated data type for genre
 *
 * Jonathan Nushi
 */

public enum Genre 
{
    MYSTERY, FANTASY, HUMOR;
}


