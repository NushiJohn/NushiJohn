/*
 * creates a non-fiction subclass for books
 *
 * Jonathan Nushi
 */

public class NonFiction extends Book
{
    private int callNumber;     //instance variable

    public NonFiction(){        //no argument constructor
        this.callNumber = 005;
    }

    public NonFiction(String title, int pages, String color, int callNumber){       //argument constructor
        setTitle(title);
        setPages(pages);
        setColor(color);
        this.callNumber = callNumber;
    }


    public final void setCallNumber(int callNumber){        //callNumber setter
        this.callNumber = callNumber;
    }

    public int getCallNumber(){     //callNumber getter
        return this.callNumber;
    }


    public boolean hasSameCallNumber(NonFiction b){     //compare two call numbers
        return this.callNumber == b.callNumber;
    }


    public int randomRating(){      //randomRating
        int rating;
        if (this.callNumber <= 333){
            rating = (int) ((Math.random() * (5-3)) + 3);
        } else if (this.callNumber <= 666){
            rating = (int) ((Math.random() * (3-1)) + 1);
        } else {rating = (int) ((Math.random() * (4-2)) + 2);
        }
        return rating;
    }


    public String toString(){       //addition of callNumber to toString
        return super.toString() + "\ncallNumber\t" + this.callNumber;
    }
}
