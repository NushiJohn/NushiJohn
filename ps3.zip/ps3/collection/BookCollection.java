/*
 * Jonathan Nushi
 */

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

public class BookCollection
{
	private ArrayList<Book> books = new ArrayList<Book>();  	// instance variable

    private Book favoriteBook;    //favoriteBook instance variable

    public final void setFavoriteBook (Book f){       //favoriteBook setter
        this.favoriteBook = f;
    }
    
    public Book getFavoriteBook(){     //favoriteBook getter
        return favoriteBook;
    }

    public BookCollection(){        //BookCollection
        super();
    }

    public void addBook(Book b) throws BannedBookException{        //method for adding books, throws error if a book is banned
		if (Book.bannedBooks().contains(b.getTitle().toUpperCase())) {
			throw new BannedBookException(b.getTitle() + " is a banned book and may not be added to your collection!");
		} else {
			this.books.add(b);
		}
    }

    public String toString(){
        return "favoriteBook\t" + favoriteBook;
    }
}
