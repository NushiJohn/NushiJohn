/*
 * Jonathan Nushi
 */

public class BannedBookException extends Exception
{
    public BannedBookException(String s) {
        // Argument Constructor
        super(s);
    }
    public BannedBookException() {
        // No Argument Constructor
        super();
    }
}
