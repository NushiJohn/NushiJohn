/*
 * creates a comparator for sorting books by color
 *
 * Jonathan Nushi
 */

import java.util.Comparator;

public class BookColorComparator implements Comparator<Book>
{
    public int compare(Book b1, Book b2){
        return b1.getColor().compareTo(b2.getColor());
    }
}	
